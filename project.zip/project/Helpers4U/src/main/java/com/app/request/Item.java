package com.app.request;

import com.app.models.SubServicesDeatils;

public class Item {

	private SubServicesDeatils subServicesDeatils;
	
	

	public Item(SubServicesDeatils subServicesDeatils) {
		super();
		this.subServicesDeatils = subServicesDeatils;
	}

	public SubServicesDeatils getSubServicesDeatils() {
		return subServicesDeatils;
	}

	public void setSubServicesDeatils(SubServicesDeatils subServicesDeatils) {
		this.subServicesDeatils = subServicesDeatils;
	}

	@Override
	public String toString() {
		return "Item [subServicesDeatils=" + subServicesDeatils + "]";
	}
	
	
	
}
