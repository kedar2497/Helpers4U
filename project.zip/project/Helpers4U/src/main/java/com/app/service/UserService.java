package com.app.service;

import com.app.models.User;

public interface UserService {
    User save(User user);

    User findByUserName(String username);
    User findByEmail(String email);
    public User findByEmailAndPassword(String email,String password);
    public User findById(Long id);
    public void deleteId(Long id);
}