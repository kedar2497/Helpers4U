package com.app.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.models.SubServicesDeatils;


public interface SubServiceRepository extends JpaRepository<SubServicesDeatils, Long> {

	public List<SubServicesDeatils> findByServiceName(String serviceName);
	
	public SubServicesDeatils findBySubServiceId(Long subServiceId);
}
