package com.app.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.models.UserOrders;
import com.app.repos.UserOrdersRepository;

@Controller
public class MyPreviousOrders {
	private static final Logger logger = LoggerFactory.getLogger(MyPreviousOrders.class);
	@Autowired
	UserOrdersRepository userOrdersRepository;

	@RequestMapping(value = "/myorder/{id}", method = RequestMethod.GET)
	public ModelAndView myOrders(@PathVariable("id") String id,HttpSession session) {
		if(id!=null) {
			ModelAndView modelAndView=new ModelAndView("/myorders");
			List<UserOrders> userOrders=userOrdersRepository.findByVendorServiceId(Long.valueOf(id));
			logger.info("In MyOrderHandler ID:{} lisUserOrders:{}",id,userOrders);
			for(UserOrders userOrders2: userOrders) {
				modelAndView.addObject("userId",userOrders2.getVendorServiceId());	
			}
			
			modelAndView.addObject("userOrders", userOrders);
			modelAndView.addObject("userId", id);
			return modelAndView;
		}else {
			ModelAndView modelAndView=new ModelAndView("/index");
			modelAndView.addObject("error", "Something Wrong Please Try AGain.");
			return modelAndView;
		}
		
		
	}
	
	
}
