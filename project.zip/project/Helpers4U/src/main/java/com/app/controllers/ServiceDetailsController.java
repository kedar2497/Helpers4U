package com.app.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.constant.ServiceConstantName;
import com.app.models.SubServicesDeatils;
import com.app.models.User;
import com.app.service.SubServiceDetailsService;
import com.app.service.UserServiceImpl;

@Controller
public class ServiceDetailsController {

	private static final Logger logger = LoggerFactory.getLogger(ServiceDetailsController.class);
	@Autowired
	SubServiceDetailsService subServiceDetailsService;
	
	@Autowired
	UserServiceImpl userServiceImpl;

	@GetMapping("/servicedet/{serviceType}/{type}/{id}")
	public ModelAndView service(@PathVariable String serviceType, @PathVariable String type,@PathVariable Long id,Model model1) {
		logger.info("ServiceType" + serviceType  );
		logger.info("UserType " + type  );
		List<SubServicesDeatils> subServicesDeatils = subServiceDetailsService.findByServiceName(serviceType);
		ModelAndView model ;
		User user=userServiceImpl.findById(id);
		logger.info("List of subServiceDetails "+ subServicesDeatils );
		logger.info("Size"+ subServicesDeatils.size() );
		logger.info("ISEmpty"+ subServicesDeatils.isEmpty() );
		if (type != null && type.equalsIgnoreCase("customer") && subServicesDeatils.isEmpty()
				&& subServicesDeatils.size()==0) {
			if(subServicesDeatils.isEmpty() && subServicesDeatils.size()==0) {
				logger.info("Inside Customer " );
				model = new ModelAndView("/index");
				
				model.addObject("type", user.getType());
	          	model.addObject("id",user.getId());
	        	model.addObject("user", user);
				model1.addAttribute("message", "Currently no Vendor Provided this Category SUBServices Chosse Another One");
				return model;
				
			}else {
				model = new ModelAndView("/servicedet");
				model.addObject("id",user.getId());
				model.addObject("subServicesDeatils", subServicesDeatils);
			}
			return model;
		} else if (type != null && type.equalsIgnoreCase("service")  && subServicesDeatils.isEmpty()
				&& subServicesDeatils.size()==0) {
			if(subServicesDeatils.isEmpty() && subServicesDeatils.size()==0 &&  subServicesDeatils.size() <=2) {
				logger.info("Inside service " );
				 model = new ModelAndView("/serviceregistration");
				 model.addObject("subServicesDeatils", new SubServicesDeatils());
				 model.addObject("id",id);
				 model.addObject("serviceType",serviceType);
				model.addObject("message", "Currently no service Added Category SUBServices Add The Service");	
			}else {
				logger.info("Inside else" );
				model = new ModelAndView("/index");
				
				model.addObject("type", user.getType());
	          	model.addObject("id",user.getId());
	        	model.addObject("user", user);
				model1.addAttribute("message", "Add Other SubServices");
				model.addObject("subServicesDeatils", subServicesDeatils);
			}
				
			
			return model;
		} else {
			logger.info("Inside else" );
			model = new ModelAndView("/servicedet");
			model.addObject("subServicesDeatils", subServicesDeatils);
			return model;
		}

	}

	@PostMapping("/regService/{id}/{serviceType}")
	public ModelAndView regService(@ModelAttribute("subServicesDeatils") SubServicesDeatils subServicesDeatils,@PathVariable Long id,
			@PathVariable String serviceType,BindingResult bindingResult) {
		
		logger.info("SubServiceDetails from JSP Page" + subServicesDeatils);
		// userValidator.validate(userForm, bindingResult);
			User user=userServiceImpl.findById(id);
		if (bindingResult.hasErrors()) {
			ModelAndView model = new ModelAndView("/serviceregistration");
			model.addObject("Error", "Somthin Wrong Please Submit Again");
		}
		if(subServicesDeatils!=null && subServicesDeatils.getServiceName()!=null ) {
			subServicesDeatils.setServiceName(subServicesDeatils.getServiceName());
			logger.info("No need to Setting ServiceName :{}" , subServicesDeatils);
		}else {
			subServicesDeatils.setServiceName(serviceType);
			logger.info("After Setting ServiceName :{}" , subServicesDeatils);
		}
		List<SubServicesDeatils> listSubServicesDeatils = subServiceDetailsService
				.findByServiceName(subServicesDeatils.getServiceName());
		logger.info("ListOF SUBService Details :{} Size:{} ",listSubServicesDeatils.toString(),listSubServicesDeatils.size());
		if (listSubServicesDeatils.size() > 2) {
			ModelAndView model = new ModelAndView("/index");
			model.addObject("type", user.getType());
          	model.addObject("id",user.getId());
        	model.addObject("user", user);
			model.addObject("message", "Add Other SubServices");
			model.addObject("subServicesDeatils", listSubServicesDeatils);
			return model;
		}
		String serviceName = ServiceConstantName.serviceNameMap.get(subServicesDeatils.getServiceName());
		int count =Integer.valueOf(listSubServicesDeatils.size()) + 1;
		String imageName = serviceName + "Image" + count+".jpg";
		subServicesDeatils.setImage(imageName);
		subServicesDeatils.setServiceEmailId(user.getEmail());
		subServicesDeatils.setVendorServiceId(user.getId());
		subServicesDeatils.setServiceName(subServicesDeatils.getServiceName());
		SubServicesDeatils subSDetails = subServiceDetailsService.saveDeatils(subServicesDeatils);
		
		ModelAndView model = new ModelAndView("/serviceregistration");
		model.addObject("serviceEmailId1", subSDetails.getServiceEmailId());
		model.addObject("vendorServiceId1", subSDetails.getVendorServiceId());
		model.addObject("image", imageName);
		model.addObject("subServicesDeatils", new SubServicesDeatils());
		return model;
	}

}
