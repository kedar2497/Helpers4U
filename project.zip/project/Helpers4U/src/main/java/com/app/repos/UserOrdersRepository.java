package com.app.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.models.UserOrders;

public interface UserOrdersRepository extends JpaRepository<UserOrders, Long> {

	public List<UserOrders> findByVendorServiceId(Long id);
}
