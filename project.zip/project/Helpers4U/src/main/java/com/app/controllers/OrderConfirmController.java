package com.app.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.models.User;
import com.app.models.UserOrders;
import com.app.repos.UserOrdersRepository;
import com.app.repos.UserRepository;
import com.app.request.Item;
import com.app.service.UserServiceImpl;

@Controller
public class OrderConfirmController {
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@Autowired
	UserOrdersRepository userRepository;

	private static final Logger logger = LoggerFactory.getLogger(OrderConfirmController.class);
	
	@RequestMapping(value = "/order/confirm//{vId}/{total}")
	public ModelAndView productIndex(@PathVariable("vId") 
	String vId,@PathVariable("total") String total, HttpSession session) {
		Object object = session.getAttribute("cart");
		
		int randomNumber;
		Random rand = new Random();
		randomNumber = rand.nextInt(1000000000);
		
		logger.info("Object Cart Inside Order {} ", object);
		List<Item> cart = (List<Item>) object;
		User user = userServiceImpl.findById(Long.valueOf(vId));
		if (cart == null || cart.isEmpty()) {
			logger.info("Cart Is Empty");
		} else {
			
			for(Item item : cart) {
				UserOrders userOrders=new UserOrders();
				userOrders.setServiceEmailId(user.getEmail());
				userOrders.setOrderId(Long.valueOf(randomNumber));
				userOrders.setSubServiceId(item.getSubServicesDeatils().getSubServiceId());
				userOrders.setServiceName(item.getSubServicesDeatils().getServiceName());
				userOrders.setSubServiceName(item.getSubServicesDeatils().getSubServiceName());
				
				userOrders.setVendorServiceId(user.getId());
				userOrders.setImage(item.getSubServicesDeatils().getImage());
				userOrders.setCost(item.getSubServicesDeatils().getCost());
				userOrders.setDescription(item.getSubServicesDeatils().getDescription());
				userOrders.setTotalCost(Long.valueOf(total));
				
				userRepository.save(userOrders);
			}

				
		
		}
		
		ModelAndView model = new ModelAndView();
		

		model = new ModelAndView("/OrderConfirmation");
		model.addObject("orderNumber", randomNumber);
		model.addObject("total",total );
		session.invalidate();
		logger.info("Returning OrderConfirmatin");

		return model;
	}
}
