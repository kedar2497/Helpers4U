package com.app.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.app.models.User;
import com.app.request.Item;
import com.app.service.SubServiceDetailsService;
import com.app.service.UserServiceImpl;

@Controller
public class CartController {

	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	SubServiceDetailsService SubServiceDetailsService;
	
	private static final Logger logger = LoggerFactory.getLogger(CartController.class);
	
	
	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String cart(HttpSession session) {
		Object object = session.getAttribute("cart");

		logger.info(" Inside /cart:{}  VID:{}", object);
		List<Item> cart = (List<Item>) object;
		session.setAttribute("cart", cart);
		logger.info("List /cart{} ", cart);
		return "cart";
	}

	@RequestMapping(value = "/product/index/{vId}", method = RequestMethod.GET)
	public ModelAndView productIndex(@PathVariable("vId") String vId, HttpSession session) {
		Object object = session.getAttribute("cart");

		logger.info("Object Cart Inside /product/index/{vId}:{}  VID:{}", object,vId);
		List<Item> cart = (List<Item>) object;
		logger.info("List Cart after{} ", cart);

		User user = userServiceImpl.findById(Long.valueOf(vId));
		ModelAndView model = new ModelAndView();
		model = new ModelAndView("/index");
		model.addObject("type", user.getType());
		model.addObject("id", user.getId());
		model.addObject("user", user);
		session.setAttribute("userId", vId);
		session.setAttribute("cart", cart);

		return model;
	}

	@RequestMapping(value = "/order/buy/{id}/{vId}", method = RequestMethod.GET)
	public String cartByLogic(@PathVariable("id") String id, @PathVariable("vId") String vId,HttpSession session) {
		// SubServicesDeatils subServicesDeatils=new SubServicesDeatils();

		logger.info("Cart Controller /order/buy/{id}/{vId} VID:{} OrderBYID :{} Session:{}", vId,id, session.getAttribute("cart"));
		Object object = session.getAttribute("cart");

		logger.info("Object Cart /order/buy/{id}/{vId} :{} ", object);
		List<Item> cart = (List<Item>) object;
		logger.info("List Cart after{} ", cart);

		if (cart == null || cart.isEmpty()) {
			cart = new ArrayList<Item>();
			cart.add(new Item(SubServiceDetailsService.findBySubServiceId(Long.valueOf(id))));
			session.setAttribute("cart", cart);
			session.setAttribute("userId", vId);
			session.setAttribute("cart", cart);
		} else {

			int index = this.exists(id, cart);
			if (index == -1) {
				cart.add(new Item(SubServiceDetailsService.findBySubServiceId(Long.valueOf(id))));
			} else {

				logger.info("This SubService Alerday Added");
			}
			session.setAttribute("userId", vId);
			session.setAttribute("cart", cart);
		}
		return "redirect:/cart";
	}

	@RequestMapping(value = "/order/remove/{id}", method = RequestMethod.GET)
	public String remove(@PathVariable("id") String id, HttpSession session) {

		List<Item> cart = (List<Item>) session.getAttribute("cart");
		int index = this.exists(id, cart);
		cart.remove(index);
		session.setAttribute("cart", cart);
		return "redirect:/cart";
	}

	private int exists(String id, List<Item> cart) {
		for (int i = 0; i < cart.size(); i++) {
			if (cart.get(i).getSubServicesDeatils().getSubServiceId() == Long.valueOf(id)) {
				return i;
			}
		}
		return -1;
	}

}
