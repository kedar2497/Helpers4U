package com.app.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "subservices")
public class SubServicesDeatils {

	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subServiceId;
	String serviceName;
	String subServiceName;
	String serviceEmailId;
	Long vendorServiceId;
	String image;
	int cost;
	String description;
	public Long getSubServiceId() {
		return subServiceId;
	}
	public void setSubServiceId(Long subServiceId) {
		this.subServiceId = subServiceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getSubServiceName() {
		return subServiceName;
	}
	public void setSubServiceName(String subServiceName) {
		this.subServiceName = subServiceName;
	}
	public String getServiceEmailId() {
		return serviceEmailId;
	}
	public void setServiceEmailId(String serviceEmailId) {
		this.serviceEmailId = serviceEmailId;
	}
	public Long getVendorServiceId() {
		return vendorServiceId;
	}
	public void setVendorServiceId(Long vendorServiceId) {
		this.vendorServiceId = vendorServiceId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "SubServicesDeatils [subServiceId=" + subServiceId + ", serviceName=" + serviceName + ", subServiceName="
				+ subServiceName + ", serviceEmailId=" + serviceEmailId + ", vendorServiceId=" + vendorServiceId
				+ ", image=" + image + ", cost=" + cost + ", description=" + description + "]";
	}
	
	
	
	
}
