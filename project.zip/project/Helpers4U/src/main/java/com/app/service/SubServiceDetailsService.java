package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.models.SubServicesDeatils;
import com.app.repos.SubServiceRepository;

@Service
public class SubServiceDetailsService {

	
	@Autowired
	SubServiceRepository subServiceRepository;
	
	public List<SubServicesDeatils> findByServiceName(String ServiceName) {
		return subServiceRepository.findByServiceName(ServiceName);
	}
	
	public SubServicesDeatils saveDeatils(SubServicesDeatils subServicesDeatils) {
		return subServiceRepository.save(subServicesDeatils);
	}
	
	public SubServicesDeatils findBySubServiceId(Long subServiceId) {
		return subServiceRepository.findBySubServiceId(subServiceId);
	}
}
