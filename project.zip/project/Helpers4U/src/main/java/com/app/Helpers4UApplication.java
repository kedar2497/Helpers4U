package com.app;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class Helpers4UApplication {

	public static void main(String[] args) {
		 SpringApplication.run(Helpers4UApplication.class, args); 
		
		
		
		/*
		 * BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(); String
		 * password = "yawinpassword"; String encodedPassword =
		 * passwordEncoder.encode(password); System.out.println();
		 * System.out.println("Password is         : " + password);
		 * System.out.println("Encoded Password is : " + encodedPassword);
		 * System.out.println();
		 * 
		 * boolean isPasswordMatch = passwordEncoder.matches(password, encodedPassword);
		 * System.out.println("Password : " + password + "   isPasswordMatch    : " +
		 * isPasswordMatch);
		 * 
		 * password = "yawin"; isPasswordMatch = passwordEncoder.matches(password,
		 * encodedPassword); System.out.println("Password : " + password +
		 * "           isPasswordMatch    : " + isPasswordMatch);
		 */
	
	}

}
