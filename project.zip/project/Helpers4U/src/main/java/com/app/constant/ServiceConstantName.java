package com.app.constant;

import java.util.HashMap;
import java.util.Map;

public class ServiceConstantName {

	
	public static Map<String, String> serviceNameMap;
	static {
		serviceNameMap = new HashMap<>();
		serviceNameMap.put("Painting", "Painting");
		serviceNameMap.put("HomeCleaning", "HomeCleaning");
		serviceNameMap.put("Plumbing", "Plumbing");
		serviceNameMap.put("Electrician", "Electrician");
		serviceNameMap.put("CarPentro", "CarPentro");
		serviceNameMap.put("CarCleaning", "CarCleaning");
		serviceNameMap.put("HomeAppliance", "HomeAppliance");
		serviceNameMap.put("PestControl", "PestControl");
		
	}
}
