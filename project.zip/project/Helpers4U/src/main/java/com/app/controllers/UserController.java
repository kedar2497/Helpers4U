package com.app.controllers;
import java.util.Enumeration;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import com.app.models.User;
import com.app.request.Credentials;
import com.app.service.UserServiceImpl;
import com.app.service.UserValidator;

@Controller
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private UserValidator userValidator;
	
	@GetMapping("/")
	public String empty(Model model) {
		model.addAttribute("userForm", new User());
		model.addAttribute("credentials", new Credentials());
		return "home";
	}
	@GetMapping("")
	public String blank(Model model) {
		model.addAttribute("userForm", new User());
		model.addAttribute("credentials", new Credentials());
		return "home";
	}
	
	@GetMapping("/logout/{id}")
	public String blank(@PathVariable("id") int id,Model model,HttpSession session,HttpServletRequest request) {
		Object object = session.getAttribute("cart");
		session.invalidate();
		
		HttpSession hs = request.getSession();
        Enumeration e = hs.getAttributeNames();
        while (e.hasMoreElements()) {
            String attr = (String) e.nextElement();
            hs.setAttribute(attr, null);
        }
        removeCookies(request);
        
        hs.invalidate();
		return "login";
	}
	 public static void removeCookies(HttpServletRequest request) {
         Cookie[] cookies = request.getCookies();
         if (cookies != null && cookies.length > 0) {
             for (int i = 0; i < cookies.length; i++) {
                 cookies[i].setMaxAge(0);
             }
         }
     }
	
	
	@GetMapping("/registration")
	public String registration(Model model) {
		model.addAttribute("userForm", new User());
		return "registration";
	}

	@PostMapping("/registration")
	public ModelAndView registration(Model model1, @ModelAttribute("userForm") User userForm,
			BindingResult bindingResult) {
		userValidator.validate(userForm, bindingResult);

		logger.info("Inside Registration");
		if (bindingResult.hasErrors()) {
			ModelAndView model = new ModelAndView("/registration");

			return model;
		}

		User user = userService.save(userForm);

		ModelAndView model = new ModelAndView("/login");
		model.addObject("type", user.getType());
		model.addObject("id", user.getId());
		System.out.println("Inside RegController Type Value " + user.getType());
		model1.addAttribute("message", "You have been Succesfully Register & Please Login.");
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(Model model1, Credentials credentials) {
		ModelAndView model;
		System.out.println("Username= " + credentials.getEmail());
		// User
		// user=userService.findByEmailAndPassword(credentials.getEmail(),credentials.getPassword());
		User user = userService.findByEmail(credentials.getEmail());
		/*
		 * boolean validator=
		 * passwordEncoder.matches(credentials.getPassword(),user.getPassword());
		 * System.out.println("UserDetails Password details check"+ validator);
		 */
		if (user != null && user.getPassword().equalsIgnoreCase(credentials.getPassword())) {
			logger.info("Correct UserName & Password :{}", user);
			model = new ModelAndView("/index");
			model.addObject("type", user.getType());
			model.addObject("id", user.getId());
			model.addObject("user", user);
		} else {
			logger.info("Correct UserName & Password :{}", user);
			model1.addAttribute("error", "Your username and password is invalid.");
			model = new ModelAndView("/login");

		}
		return model;
	}

	@RequestMapping(value = "/getUserDetails/{userId}", method = RequestMethod.GET)
	public ModelAndView getUserDetails(@PathVariable int userId) {
		ModelAndView model = new ModelAndView("/userDetails");

		User user = new User();

		model.addObject("user", user);
		return model;
	}

	@GetMapping("/login")
	public String login(Model model, String error, String logout) {
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");

		return "login";
	}

	@GetMapping("/index")
	public String welcome(Model model) {
		return "index";
	}

	@RequestMapping(value = "/detailsUser/{id}", method = RequestMethod.GET)
	public ModelAndView userDetails(@PathVariable Long id) {
		if (id != null) {
			ModelAndView model = new ModelAndView();
			User user = userService.findById(id);
			model.addObject("user", user);
			model.setViewName("edit");
			return model;
		} else {
			ModelAndView modelAndView = new ModelAndView("/index");
			modelAndView.addObject("error", "Something Wrong Please Try AGain.");
			return modelAndView;
		}
	}

	@RequestMapping(value = "/editUser/{id}", method = RequestMethod.GET)
	public ModelAndView editUser(@PathVariable Long id) {
		if (id != null) {
			ModelAndView model = new ModelAndView();
			User user = userService.findById(id);
			
			model.setViewName("/editdetails");
			model.addObject("id", user.getId());
			model.addObject("user", user);
			return model;
		} else {
			ModelAndView modelAndView = new ModelAndView("/index");
			modelAndView.addObject("error", "Something Wrong Please Try AGain.");
			return modelAndView;
		}
	}

	@RequestMapping(value = "/deleteUser/{id}", method = RequestMethod.GET)
	public ModelAndView deleteUser(@PathVariable("id") Long id) {
		if (id != null) {
			userService.deleteId(id);
			return new ModelAndView("login");
		} else {
			ModelAndView modelAndView = new ModelAndView("/index");
			modelAndView.addObject("error", "Something Wrong Please Try AGain.");
			return modelAndView;
		}

	}
	
	@RequestMapping(value = "/save/{id}", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("user") User user,@PathVariable("id") Long id) {
	    User userObject=userService.findById(id);
	     userObject.setFirstName(user.getFirstName());
	     userObject.setLastName(user.getLastName());
	     userService.save(userObject);
	    return "login";
	}

}